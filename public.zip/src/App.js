import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import "tw-elements";
import Home from './components/Pages/Home';
import About from './components/Pages/About';
import Services from './components/Pages/Services';
import ServicesOne from './components/Pages/ServicesOne';
import ServicesTwo from './components/Pages/ServicesTwo';
import ServicesThree from './components/Pages/ServicesThree';
import LetsTalk from './components/Pages/LetsTalk';
import OurWork from './components/Pages/OurWork';
import Team from './components/Pages/Team';
import Header from "./components/Header/Header";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Header/>
      <section className="main-site">
        <div className="container">
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/about" element={<About />} />
            <Route exact path="/services" element={<Services />} />
            <Route exact path="/services-one" element={<ServicesOne />} />
            <Route exact path="/services-two" element={<ServicesTwo />} />
            <Route exact path="/services-three" element={<ServicesThree />} />
            <Route exact path="/our-work" element={<OurWork />} />
            <Route exact path="/our-team" element={<Team />} />
            <Route exact path="/lets-talk" element={<LetsTalk />} />
          </Routes>
        </div>
      </section>
      </BrowserRouter>
    </div>
  );
}

export default App;
