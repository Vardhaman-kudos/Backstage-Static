import React from "react";

function HomePage() {
  return (
    <>
      This is Home Page
    </>
  );
}

export default HomePage;
