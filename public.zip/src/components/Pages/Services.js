import React from "react";

function ServicesPage() {
  return (
    <>
      This is Services Page
    </>
  );
}

export default ServicesPage;
