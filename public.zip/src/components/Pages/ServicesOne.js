import React from "react";

function ServicesOnePage() {
  return (
    <>
      This is Services One Page
    </>
  );
}

export default ServicesOnePage;
