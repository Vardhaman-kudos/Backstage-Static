import React from "react";

function TeamPage() {
  return (
    <>
      This is Team Page
    </>
  );
}

export default TeamPage;
