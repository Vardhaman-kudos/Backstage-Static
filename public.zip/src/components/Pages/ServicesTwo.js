import React from "react";

function ServicesTwoPage() {
  return (
    <>
      This is Services Two Page
    </>
  );
}

export default ServicesTwoPage;
