import React from "react";

function LetsTalkPage() {
  return (
    <>
      This is Lets Talk Page
    </>
  );
}

export default LetsTalkPage;
