import React from "react";

function AboutPage() {
  return (
    <>
      This is About Page
    </>
  );
}

export default AboutPage;
