export const menuItems = [
  {
    title: "Home",
    to: "",
  },
  {
    title: "About",
    to: "about",
    submenu: [
      {
        title: "Services One",
        to: "services-one",
      },
      {
        title: "Services Two",
        to: "services-two",
      },
      {
        title: "Services Three",
        to: "services-three",
      },
    ],
  },
  {
    title: "Services",
    to: "services",
    submenu: [
      {
        title: "Services One",
        to: "services-one",
      },
      {
        title: "Services Two",
        to: "services-two",
      },
      {
        title: "Services Three",
        to: "services-three",
      },
    ],
  },
  {
    title: "Our Work",
    to: "our-work",
  },
  {
    title: "Our Team",
    to: "our-team",
  },
  {
    title: "Let's Talk",
    to: "lets-talk",
  },
];
