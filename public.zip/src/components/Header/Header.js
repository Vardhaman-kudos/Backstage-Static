import React from "react";
import Navbar from "../Navigation/Navbar";
import SearchField from "../Searchbar/SearchBar";
import Logo from "./Logo";
import PhoneIcon from "./PhoneIcon";


function Header() {
  return (
    <>
      <header className="site-header p-20">
        <div className="container">
          <div className="flex flex-wrap justify-between">
            <div className="header-left">
              <div className="site-logo">
                <Logo />
              </div>
            </div>
            <div className="header-right flex items-center">
              <Navbar />
              <PhoneIcon />
              <SearchField/>


              <div class="flex space-x-2 hidden">
                <div>
                  <a
                    class="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg  focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out mr-1.5"
                    data-bs-toggle="offcanvas"
                    href="#offcanvasExample"
                    role="button"
                    aria-controls="offcanvasExample"
                  >
                    Link with href
                  </a>
                  <div
                    class="offcanvas offcanvas-start fixed bottom-0 flex flex-col max-w-full bg-white invisible bg-clip-padding shadow-sm outline-none transition duration-300 ease-in-out text-gray-700 top-0 left-0 border-none w-96"
                    tabindex="-1"
                    id="offcanvasExample"
                    aria-labelledby="offcanvasExampleLabel"
                  >
                    <div class="offcanvas-header flex items-center justify-between p-4">
                      <h5
                        class="offcanvas-title mb-0 leading-normal font-semibold"
                        id="offcanvasExampleLabel"
                      >
                        Offcanvas
                      </h5>
                      <button
                        type="button"
                        class="btn-close box-content w-4 h-4 p-2 -my-5 -mr-2 text-black border-none rounded-none opacity-50 focus:shadow-none focus:outline-none focus:opacity-100 hover:text-black hover:opacity-75 hover:no-underline"
                        data-bs-dismiss="offcanvas"
                        aria-label="Close"
                      ></button>
                    </div>
                    <div class="offcanvas-body flex-grow p-4 overflow-y-auto">
                    This is content
                    <Navbar />
                      <div class="" id="sidenavExample">
                        <ul class="relative">
                          <li class="relative" id="sidenavEx1">
                            <a
                              class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out cursor-pointer"
                              data-mdb-ripple="true"
                              data-mdb-ripple-color="dark"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseSidenavEx1"
                              aria-expanded="true"
                              aria-controls="collapseSidenavEx1"
                            >
                              <span>Click here 1</span>
                              <svg
                                aria-hidden="true"
                                focusable="false"
                                data-prefix="fas"
                                class="w-3 h-3 ml-auto"
                                role="img"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 448 512"
                              >
                                <path
                                  fill="currentColor"
                                  d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"
                                ></path>
                              </svg>
                            </a>
                            <ul
                              class="relative accordion-collapse collapse"
                              id="collapseSidenavEx1"
                              aria-labelledby="sidenavEx1"
                              data-bs-parent="#sidenavExample"
                            >
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 1
                                </a>
                              </li>
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 2
                                </a>
                              </li>
                            </ul>
                          </li>
                          <li class="relative" id="sidenavEx2">
                            <a
                              class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out cursor-pointer"
                              data-mdb-ripple="true"
                              data-mdb-ripple-color="dark"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseSidenavEx2"
                              aria-expanded="false"
                              aria-controls="collapseSidenavEx2"
                            >
                              <span>Click here 2</span>
                              <svg
                                aria-hidden="true"
                                focusable="false"
                                data-prefix="fas"
                                class="w-3 h-3 ml-auto"
                                role="img"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 448 512"
                              >
                                <path
                                  fill="currentColor"
                                  d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"
                                ></path>
                              </svg>
                            </a>
                            <ul
                              class="relative accordion-collapse collapse"
                              id="collapseSidenavEx2"
                              aria-labelledby="sidenavEx2"
                              data-bs-parent="#sidenavExample"
                            >
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 3
                                </a>
                              </li>
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 4
                                </a>
                              </li>
                            </ul>
                          </li>
                          <li class="relative" id="sidenavEx3">
                            <a
                              class="flex items-center text-sm py-4 px-6 h-12 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out cursor-pointer"
                              data-mdb-ripple="true"
                              data-mdb-ripple-color="dark"
                              data-bs-toggle="collapse"
                              data-bs-target="#collapseSidenavEx3"
                              aria-expanded="false"
                              aria-controls="collapseSidenavEx3"
                            >
                              <span>Click here 3</span>
                              <svg
                                aria-hidden="true"
                                focusable="false"
                                data-prefix="fas"
                                class="w-3 h-3 ml-auto"
                                role="img"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 448 512"
                              >
                                <path
                                  fill="currentColor"
                                  d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"
                                ></path>
                              </svg>
                            </a>
                            <ul
                              class="relative accordion-collapse collapse"
                              id="collapseSidenavEx3"
                              aria-labelledby="sidenavEx3"
                              data-bs-parent="#sidenavExample"
                            >
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 5
                                </a>
                              </li>
                              <li class="relative">
                                <a
                                  href="#!"
                                  class="flex items-center text-xs py-4 pl-12 pr-6 h-6 overflow-hidden text-gray-700 text-ellipsis whitespace-nowrap rounded hover:text-gray-900 hover:bg-gray-100 transition duration-300 ease-in-out"
                                  data-mdb-ripple="true"
                                  data-mdb-ripple-color="dark"
                                >
                                  Link 6
                                </a>
                              </li>
                            </ul>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
