import React from "react";
import { FaPhoneAlt } from "react-icons/fa";


function PhoneIcon() {
  return (
    <>
    <div className="phone-icon">
      <a href="tel:9510190209">
        <FaPhoneAlt/>
      </a>
    </div>
    </>
  );
}

export default PhoneIcon;
