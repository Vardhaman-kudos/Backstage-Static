import React from "react";
import LogoImg from '../../assets/images/logo.png';

function Logo () {
    return (
        <>
        <a href="/">
            <img src={LogoImg} alt="Site Logo" />
        </a>
        </>
    );
}

export default Logo;