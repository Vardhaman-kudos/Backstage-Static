import { useState, useEffect, useRef } from "react";
import { NavLink } from "react-router-dom";
import Dropdown from "./Dropdown";

const MenuItems = ({ items, depthLevel }) => {
  const [dropdown, setDropdown] = useState(false);

  const [isActive, setIsActive] = useState(false);

  const handleClick = event => {
    setIsActive(current => !current);
  };

  let ref = useRef();



  useEffect(() => {
    function handler(event) {
      if (dropdown && ref.current && !ref.current.contains(event.target)) {
        setDropdown(false);
      }
    }
    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {
      // Cleanup the event listener
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };
  }, [dropdown]); 

  function onMouseEnter() {
    window.innerWidth < 767 && setDropdown(true);
  }

  function onMouseLeave() {
    window.innerWidth < 767 && setDropdown(false);
  };

  return (
    <>
      <li
      id="menu-items"
        className={isActive ? 'expand-submenu' : ''}
        ref={ref}
      >
        {items.submenu ? (
          <>
            <NavLink exact className="navbar-item" to={ '/' + items.to}>
              {items.title}{" "}
            </NavLink>
            {depthLevel > 0 ? (
                <span>&raquo;</span>
              ) : (
                <span  onClick={handleClick} className="arrow" />
              )}
            <Dropdown
              depthLevel={depthLevel}
              submenus={items.submenu}
              dropdown={dropdown}
            />
          </>
        ) : (
          <NavLink exact className="navbar-item" to={ '/' + items.to}>
            {items.title}
          </NavLink>
        )}
      </li>
    </>
  );
};

export default MenuItems;
