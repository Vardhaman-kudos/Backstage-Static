import { useState, useEffect, useRef } from "react";
import { NavLink } from "react-router-dom";
import Dropdown from "./Dropdown";

const MenuItems = ({ items, depthLevel }) => {
  const [dropdown] = useState(false);

  let ref = useRef();

  return (
    <>
      <li
        className="menu-items"
        ref={ref}
      >
        {items.submenu ? (
          <>
            <NavLink exact className="navbar-item" to={ '/' + items.to}>
              {items.title}{" "}
              {depthLevel > 0 ? (
                <span>&raquo;</span>
              ) : (
                <span className="arrow" />
              )}
            </NavLink>
            <Dropdown
              depthLevel={depthLevel}
              submenus={items.submenu}
              dropdown={dropdown}
            />
          </>
        ) : (
          <NavLink exact className="navbar-item" to={ '/' + items.to}>
            {items.title}
          </NavLink>
        )}
      </li>
    </>
  );
};

export default MenuItems;
