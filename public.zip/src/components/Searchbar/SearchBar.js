import React, { useState } from "react";
import styles from './search.css'
import './search.css'
import { FaSearch } from "react-icons/fa";

function SearchField() {
  const [Img, setImg] = useState("");
  const inputEvent = (event) => {
    const data = event.target.value;
    setImg(data);
  };
  return (
    <>
      <div className="searchbar">
        <div class="flex justify-center">
          <div>
            <div class="dropdown relative">
              <a
                class="dropdown-toggle"
                id="dropdownMenuButton1"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <FaSearch />
              </a>
              <div
                class="
                  dropdown-menu
                  absolute
                  hidden
                  bg-white
                  z-50
                  text-left
                  rounded-lg
                  shadow-lg
                  hidden
                  border-none
                  "
                aria-labelledby="dropdownMenuButton1"
              >
                <input
                  className="searchbar"
                  type="text"
                  placeholder="Search..."
                  onChange={inputEvent}
                  value={Img}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default SearchField;
