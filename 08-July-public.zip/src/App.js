import React, { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import axios from "axios";
import HomePage from "./components/Pages/Home";
import AboutPage from "./components/Pages/About";
import ContactPage from "./components/Pages/Contact";
import IndustriesPage from "./components/Pages/Industries";
import NetsuiteServicesPage from "./components/Pages/NetsuiteServices";
import ResourcesPage from "./components/Pages/Resources";
import Header from "./components/Header/Header";

function App() {
 
  const [homeData, sethomeData] = useState([]);
  const [aboutData, setaboutData] = useState([]);
  const [contactData, setcontactData] = useState([]);
  const [industriesData, setindustriesData] = useState([]);
  const [netsuiteservicesData, setnetsuiteservicesData] = useState([]);
  const [resourcesData, setresourcesData] = useState([]);

  const url = "http://ncisiv.kudosintech.com";

  const templates =  {'home': url+"/wp-json/wp/v2/pages/10",
                      'about': url+'/wp-json/wp/v2/pages/11',
                      'contact': url+'/wp-json/wp/v2/pages/12',
                      'industries': url+'/wp-json/wp/v2/pages/13',
                      'netsuite-services': url+'/wp-json/wp/v2/pages/14',
                      'resources': url+'/wp-json/wp/v2/pages/15',
                     }

  useEffect(() => {
    function fetchData() {
      axios.get(templates['home'])
        .then((response) => {
          sethomeData(response.data);
        });
    }
    fetchData();
  }, []);

  useEffect(() => {
    function fetchData() {
      axios.get(templates['about'])
        .then((response) => {
          setaboutData(response.data);
        });
    }
    fetchData();
  }, []);

  useEffect(() => {
    function fetchData() {
      axios.get(templates['contact'])
        .then((response) => {
          setaboutData(response.data);
        });
    }
    fetchData();
  }, []);

  useEffect(() => {
    function fetchData() {
      axios.get(templates['industries'])
        .then((response) => {
          setaboutData(response.data);
        });
    }
    fetchData();
  }, []);

  useEffect(() => {
    function fetchData() {
      axios.get(templates['netsuite-services'])
        .then((response) => {
          setaboutData(response.data);
        });
    }
    fetchData();
  }, []);

  useEffect(() => {
    function fetchData() {
      axios.get(templates['resources'])
        .then((response) => {
          setaboutData(response.data);
        });
    }
    fetchData();
  }, []);

  return (
    <>
      <BrowserRouter>
        <div className="App">
        <Header/>
          <Routes>
            {/* <Route path='/home' element={<HomePage props = {homeData}/>} />
            <Route path='/about' element={<AboutPage props = {aboutData}/>} />
            <Route path='/contact' element={<ContactPage props = {contactData}/>} />
            <Route path='/industries' element={<IndustriesPage props = {industriesData}/>} />
            <Route path='/netsuite-services' element={<NetsuiteServicesPage props = {netsuiteservicesData}/>} />
            <Route path='/resources' element={<ResourcesPage props = {resourcesData}/>} /> */}

            <Route exact path='/' element={<HomePage/>} />
            <Route exact path='/about' element={<AboutPage/>} />
            <Route exact path='/contact' element={<ContactPage/>} />
            <Route exact path='/industries' element={<IndustriesPage/>} />
            <Route exact path='/netsuite-services' element={<NetsuiteServicesPage/>} />
            <Route exact path='/resources' element={<ResourcesPage/>} />
          </Routes>
        </div>
      </BrowserRouter>
    </>
  );
}

export default App;