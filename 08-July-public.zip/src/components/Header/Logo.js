import React from "react";


function Logo() {
  return (
    <>
    <div className="site-logo py-15">
      <a href="/">
        <img src="http://ncisiv.kudosintech.com/wp-content/uploads/2022/07/NCISIV-1-1.svg" alt="Logo" title="Logo" width="270" height="68" />
      </a>
    </div>
    </>
  );
}

export default Logo;
