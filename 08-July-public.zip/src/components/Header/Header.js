import React from "react";
import Logo from "./Logo";
import Navigation from "./navigation/Navigation";
import SocialIcon from "../social-icon/Socialicon"
import SearchBar from "../search/SearchBar";
import LetsTalk from "../Lets-talk/LetsTalk";

function Header() {
  return (
    <>
      <header className="site-header pl-30">
        <div className="container-full">
          <div className="flex flex-wrap w-full">
            <div className="row-col mr-100">
              <div className="site-logo">
                <Logo/>
              </div>
            </div>
            <div className="row-col flex items-center">
              <Navigation />
            </div>
            <div className="row-col ml-100">
            <div className="flex flex-wrap h-full">
              <SocialIcon />
              <LetsTalk />
              <SearchBar />
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
