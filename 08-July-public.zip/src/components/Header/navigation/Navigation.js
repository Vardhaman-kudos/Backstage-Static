import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, NavLink } from "react-router-dom";

function Navigation() {
  const [mainmenu, setMenu] = useState(false);

  useEffect(() => {
    function fetchData() {
      axios.get("http://ncisiv.kudosintech.com/wp-json/wp/v2/menu")
        .then((response) => {
          setMenu(response.data);
        });
    }
    fetchData();
  }, []);

  return (
    <>
      <nav className="site-navigation">
        <ul className="nav-menu flex flex-wrap items-center">
          {mainmenu &&
            mainmenu.length &&
            mainmenu.map((menuitems, index) => {
              return (
                <>
                  <li className="menu-items">
                    <NavLink exact key={menuitems.id} to={`${menuitems.title.replace(' ','-').toLowerCase()}`}>
                      {menuitems.title}
                    </NavLink>
                    {menuitems.submenu.length ? (
                      <ul className="sub-menu pl-20">
                        {menuitems.submenu.map((submenu) => (
                          <li key={submenu.ID}>                          
                            <NavLink exact key={submenu.id} to={`${submenu.title.replace(' ','-').toLowerCase()}`}>
                              {submenu.title}
                            </NavLink>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      ""
                    )}
                  </li>
                </>
              );
            })}
        </ul>
      </nav>
    </>
  );
}

export default Navigation;
