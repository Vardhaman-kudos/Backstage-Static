import React, { useState } from "react";
import './lets-talk.scss';
import { FaSearch } from "react-icons/fa";

function LetsTalk() {

  return (
    <>
    <div className="lets-talk-info bg-black p-30 flex text-white">
      Let's Talksss
      </div>
    </>
  );
}

export default LetsTalk;
