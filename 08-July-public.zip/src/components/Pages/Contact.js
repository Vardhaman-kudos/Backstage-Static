import React from "react";

// function ContactPage(props) {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }

function ContactPage() {
  return (
    <>
    This is Contact Page
  </>
  );
}

export default ContactPage;
