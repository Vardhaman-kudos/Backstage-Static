import React from "react";

// function AboutPage() {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }


function AboutPage() {
  return (
    <>
      This is About Page
    </>
  );
}

export default AboutPage;
