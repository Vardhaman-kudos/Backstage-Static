import React from "react";

// function ResourcesPage(props) {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }


function ResourcesPage() {
  return (
    <>
    This is ResourcesPage Page
  </>
  );
}



export default ResourcesPage;
