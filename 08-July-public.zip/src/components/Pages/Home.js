import React from "react";

// const HomePage =(props) => {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }

const HomePage =() => {
  return (
    <>
    This is HomePage Page
  </>
  );
}


export default HomePage;
