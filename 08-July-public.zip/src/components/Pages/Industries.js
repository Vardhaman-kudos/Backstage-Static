import React from "react";

// function IndustriesPage(props) {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }

function IndustriesPage() {
  return (
    <>
    This is IndustriesPage Page
  </>
  );
}

export default IndustriesPage;
