import React from "react";

// function NetsuiteServicesPage(props) {
//   const data = props.props;
//   return (
//       <div className="users">
//        <p>{data.id}</p>
//     </div>
//   );
// }

function NetsuiteServicesPage() {
  return (
    <>
    This is NetsuiteServicesPage Page
  </>
  );
}

export default NetsuiteServicesPage;
