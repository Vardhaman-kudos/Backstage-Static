import React from "react";

function SocialIcon() {
  return (
    <>
    <div className="social-icon">
      Social icon
      </div>
    </>
  );
}

export default SocialIcon;
